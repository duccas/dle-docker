Dear friends,

Before you start working with the script we recommend you read yourself 
the documentation in the file Documentation/readme.chm

Instructions for a new installation script is in the file Documentation/install.html

How to update the script from older versions is in the file Documentation/upgrade.html


Дорогие друзья,

Прежде чем приступать к работе со скриптом мы рекомендуем вам ознакомится 
с документацией, которая находится в файле Documentation/readme.chm

Инструкция по новой установке скрипта находится в файле Documentation/install.html

Инструкция по обновлению скрипта с более старых версий находится в файле Documentation/upgrade.html


Дорогі друзі,

Перш ніж приступити до роботи зі скриптом, ми рекомендуємо вам ознайомитися
з документацією, яка розташована у файлі Documentation/readme.chm

Інструкція з нового встановлення скрипта є у файлі Documentation/install.html

Інструкція з оновлення скрипта зі старіших версій є у файлі Documentation/upgrade.html